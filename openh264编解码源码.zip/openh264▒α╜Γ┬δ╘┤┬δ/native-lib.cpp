#include <jni.h>
#include <string>
#include "commominc/codec_api.h"
#include "commominc/memory_align.h"
#include "commominc/codec_app_def.h"
#include <assert.h>
#include <stdlib.h>

ISVCEncoder *isvcEncoder=NULL;
ISVCDecoder *isvcDecoder=NULL;




extern "C" {

JNIEXPORT jint JNICALL
Java_com_example_jerry_openh264test_h264Utils_initEncode(JNIEnv *env, jclass type) {

    int ret=WelsCreateSVCEncoder(&isvcEncoder);
    if(ret != 0){
        return -1;
    }
    return 0;

}



JNIEXPORT jint JNICALL
Java_com_example_jerry_openh264test_h264Utils_DoEncoded(JNIEnv *env, jclass type,
                                                       jbyteArray frameData_, jint width, jint height, jbyteArray encodeData_) {

    SEncParamBase paramBase;
    memset(&paramBase,0, sizeof(SEncParamBase));
    paramBase.iUsageType=CAMERA_VIDEO_REAL_TIME;
    paramBase.fMaxFrameRate=5000000;
    paramBase.iPicWidth=width;
    paramBase.iPicHeight=height;
    paramBase.iTargetBitrate=5000000;
    isvcEncoder->Initialize(&paramBase);

    int videoFormat=videoFormatI420;
    isvcEncoder->SetOption(ENCODER_OPTION_DATAFORMAT,&videoFormat);

    SFrameBSInfo info;
    SSourcePicture picture;
    memset(&info,0, sizeof(SFrameBSInfo));
    memset(&picture,0, sizeof(SSourcePicture));
    jbyte *frameData = env->GetByteArrayElements(frameData_, NULL);

    picture.iPicHeight=height;
    picture.iPicWidth=width;
    picture.iColorFormat=videoFormatI420;
    picture.iStride[0]=picture.iPicWidth;
    picture.iStride[1]=picture.iStride[2]=picture.iPicWidth>>1;
    picture.pData[0]= (unsigned char *) frameData;
    picture.pData[1]= picture.pData[0]+width*height;
    picture.pData[2]=picture.pData[1]+(width*height>>2);


    int rv= isvcEncoder->EncodeFrame(&picture,&info);
    if(rv != 0) {
        return -1;
    }

    int encode_len = 0;
    unsigned char* encodeBuf = new unsigned char[info.iFrameSizeInBytes];
    memset(encodeBuf, 0, info.iFrameSizeInBytes);
    const unsigned char start_code[4] = {0, 0, 0, 1};
    for(int layer = 0; layer < info.iLayerNum; ++layer) {
        const SLayerBSInfo& layerInfo = info.sLayerInfo[layer];

        size_t layer_len = 0;
        for (int nal = 0; nal < layerInfo.iNalCount; ++nal) {
            assert(layerInfo.pNalLengthInByte[nal]>=4);
            assert(layerInfo.pBsBuf[layer_len+0]==start_code[0]);
            assert(layerInfo.pBsBuf[layer_len+1]==start_code[1]);
            assert(layerInfo.pBsBuf[layer_len+2]==start_code[2]);
            assert(layerInfo.pBsBuf[layer_len+3]==start_code[3]);
            layer_len += layerInfo.pNalLengthInByte[nal];
        }

        memcpy(encodeBuf +encode_len,
               layerInfo.pBsBuf,
               layer_len);
        encode_len += layer_len;
    }

    encodeData_ = env->NewByteArray(encode_len);

   // jbyte *frameData = env->GetByteArrayElements(frameData_, NULL);

    env->SetByteArrayRegion(encodeData_, 0, encode_len, (const jbyte *) encodeBuf);
    env->ReleaseByteArrayElements(frameData_, frameData, 0);
    if(encodeBuf) delete encodeBuf;
    return 0;
}

JNIEXPORT jint JNICALL
Java_com_example_jerry_openh264test_h264Utils_DestoryEncode(JNIEnv *env, jclass type) {
    if(isvcEncoder) {
        isvcEncoder->Uninitialize();
        WelsDestroySVCEncoder(isvcEncoder);
        isvcEncoder = NULL;
    }
    return 0;
}


JNIEXPORT jint JNICALL
Java_com_example_jerry_openh264test_h264Utils_initDecode(JNIEnv *env, jclass type) {

    long ret= WelsCreateDecoder(&isvcDecoder);
    if(ret != 0){
        return -1;
    }

    return 0;
}


JNIEXPORT jint JNICALL
Java_com_example_jerry_openh264test_h264Utils_DoDecode(JNIEnv *env, jclass type,
                                                       jbyteArray encodeData_, jbyteArray frameData_, jint width, jint height) {

    SDecodingParam sDecParam = {0};
    sDecParam.bParseOnly = false;
    sDecParam.uiTargetDqLayer = (unsigned char) - 1;
    sDecParam.eEcActiveIdc = ERROR_CON_SLICE_COPY;
    sDecParam.sVideoProperty.size = sizeof(SVideoProperty);
    sDecParam.sVideoProperty.eVideoBsType = VIDEO_BITSTREAM_AVC;
    if (isvcDecoder->Initialize (&sDecParam)) {
        return -1;
    }

    SBufferInfo sDstBufInfo;
    memset(&sDstBufInfo, 0, sizeof(SBufferInfo));
    unsigned char* pData[3] = {NULL};
    jint encode_len = env->GetArrayLength(encodeData_);
    jbyte *encodeData = env->GetByteArrayElements(encodeData_, NULL);
    isvcDecoder->DecodeFrameNoDelay((const unsigned char*)encodeData, encode_len, pData, &sDstBufInfo);
    if (!sDstBufInfo.iBufferStatus) {
        return -1;
    }

    // now malloc framedata by width*height*1.5 size from I420
    int iWidth = sDstBufInfo.UsrData.sSystemBuffer.iWidth;
    int iHeight = sDstBufInfo.UsrData.sSystemBuffer.iHeight;
    int* iStride = sDstBufInfo.UsrData.sSystemBuffer.iStride;
    int frameSize = (iWidth*iHeight*3)>>1;
    unsigned char* frameData = (unsigned char*)malloc(frameSize);

    // copy pData[0] to yuvdata
    unsigned char* pPtr = pData[0];
    for (int i = 0; i < iHeight; i++) {
        memcpy(frameData, pPtr, iWidth);
        pPtr += iStride[0];
        frameData += iWidth;
    }

    // copy pData[1] to yuvdata
    iHeight = iHeight / 2;
    iWidth = iWidth / 2;
    pPtr = pData[1];
    for (int i = 0; i < iHeight; i++) {
        memcpy(frameData, pPtr, iWidth);
        pPtr += iStride[1];
        frameData += iWidth;
    }

    // copy pData[2] to yuvdata
    pPtr = pData[2];
    for (int i = 0; i < iHeight; i++) {
        memcpy(frameData, pPtr, iWidth);
        pPtr += iStride[1];
        frameData += iWidth;
    }

    width = iWidth; // frame width
    height = iHeight; // frame height
    frameData_ = env->NewByteArray(frameSize);
    env->SetByteArrayRegion(frameData_, 0,frameSize , (const jbyte *) frameData);
    env->ReleaseByteArrayElements(encodeData_, encodeData, 0);
    if(frameData) free(frameData);
    return 0;
}

JNIEXPORT jint JNICALL
Java_com_example_jerry_openh264test_h264Utils_DestoryDecode(JNIEnv *env, jclass type) {
    if(isvcDecoder) {
        isvcDecoder->Uninitialize();
        WelsDestroyDecoder(isvcDecoder);
        isvcDecoder = NULL;
    }
    return 0;
}

}